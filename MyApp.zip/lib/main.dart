import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:helloworld/firebase_options.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Contact List App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const AuthenticationScreen(),
    );
  }
}

class AuthenticationScreen extends StatelessWidget {
  const AuthenticationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Authentication'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () async {
                try {
                  await _signInWithEmailAndPassword(context);
                } catch (e) {
                  // Handle authentication errors
                  print('Error: $e');
                }
              },
              child: const Text('Email/Password Login'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _signInWithEmailAndPassword(BuildContext context) async {
    try {
      UserCredential userCredential =
          await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: 'user@example.com', // Replace with actual email and password
        password: 'password',
      );
      // Successful login, navigate to HomeScreen
      Navigator.of(context).pushReplacement(MaterialPageRoute(
        builder: (context) => const HomeScreen(),
      ));
    } catch (e) {
      // Handle authentication errors
      print('Error: $e');
    }
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      // User is authenticated, display content
      return Scaffold(
        appBar: AppBar(
          title: Text('Welcome, ${user.displayName ?? 'User'}'),
        ),
        body: const Center(
          child: Text('Home Screen Content'),
        ),
      );
    } else {
      // User is not authenticated, return to AuthenticationScreen
      Navigator.of(context).pushReplacement(MaterialPageRoute(
        builder: (context) => const AuthenticationScreen(),
      ));
      return const CircularProgressIndicator();
    }
  }
}

class ContactListScreen extends StatelessWidget {
  final List<Contact> contacts; // Replace with your actual contact data.

  const ContactListScreen({super.key, required this.contacts});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Contact List'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () {
              // Implement logout functionality
              FirebaseAuth.instance.signOut();
              // Navigate back to the AuthenticationScreen or any other desired screen.
            },
          ),
        ],
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('contacts').snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const CircularProgressIndicator(); // Loading indicator while data is fetched.
          }
          final contacts = snapshot.data!.docs.map((doc) {
            final data = doc.data() as Map<String, dynamic>;
            return Contact(
              id: doc.id,
              name: data['name'],
              email: data['email'],
            );
          }).toList();

          return ListView.builder(
            itemCount: contacts.length,
            itemBuilder: (context, index) {
              final contact = contacts[index];
              return ListTile(
                title: Text(contact.name),
                subtitle: Text(contact.email),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.edit),
                      onPressed: () {
                        // Implement edit contact functionality
                        // Navigate to the EditContactScreen with the selected contact.
                        Navigator.of(context).push(MaterialPageRoute(
                          builder: (context) =>
                              EditContactScreen(contact: contact),
                        ));
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete),
                      onPressed: () {
                        // Show the confirmation dialog before deleting the contact.
                        _confirmDeleteContact(context, contact);
                      },
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }

  Future<void> _confirmDeleteContact(
      BuildContext context, Contact contact) async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Confirm Deletion'),
          content: const SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                Text('Are you sure you want to delete this contact?'),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: const Text('Delete'),
              onPressed: () async {
                // Implement contact deletion functionality
                // Use Firebase Firestore to delete the contact.
                await FirebaseFirestore.instance
                    .collection('contacts')
                    .doc(contact.id)
                    .delete();
                // After deletion, navigate back to ContactListScreen.
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
}

class Contact {
  final String id; // Unique ID for the contact.
  final String name;
  final String email;

  Contact({required this.id, required this.name, required this.email});
}

class AddContactScreen extends StatelessWidget {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();

  AddContactScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add Contact'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: nameController,
              decoration: const InputDecoration(labelText: 'Name'),
            ),
            TextField(
              controller: emailController,
              decoration: const InputDecoration(labelText: 'Email'),
            ),
            ElevatedButton(
              onPressed: () async {
                final name = nameController.text;
                final email = emailController.text;
                if (name.isNotEmpty && email.isNotEmpty) {
                  // Add the new contact to Firebase Firestore.
                  await FirebaseFirestore.instance.collection('contacts').add({
                    'name': name,
                    'email': email,
                  });
                  // After adding, navigate back to ContactListScreen.
                  Navigator.of(context).pop();
                } else {
                  // Show an error message or validation message to the user.
                }
              },
              child: const Text('Add Contact'),
            ),
          ],
        ),
      ),
    );
  }
}

class EditContactScreen extends StatelessWidget {
  final Contact contact;

  EditContactScreen({super.key, required this.contact});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit Contact'),
      ),
      body: Center(
        child: Column(
          children: [
            Text('Edit Contact for: ${contact.name}'),
            // Implement the form fields and update logic here.
          ],
        ),
      ),
    );
  }
}

void _confirmDeleteContact(BuildContext context, Contact contact) {
  showDialog<void>(
    context: context,
    barrierDismissible: false,
    builder: (BuildContext context) {
      return AlertDialog(
        title: const Text('Confirm Deletion'),
        content: const SingleChildScrollView(
          child: ListBody(
            children: <Widget>[
              Text('Are you sure you want to delete this contact?'),
            ],
          ),
        ),
        actions: <Widget>[
          TextButton(
            child: const Text('Cancel'),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
          TextButton(
            child: const Text('Delete'),
            onPressed: () async {
              // Implement contact deletion functionality
              // Use Firebase Firestore to delete the contact.
              await FirebaseFirestore.instance
                  .collection('contacts')
                  .doc(contact.id)
                  .delete();
              // After deletion, navigate back to ContactListScreen.
              Navigator.of(context).pop();
            },
          ),
        ],
      );
    },
  );
}
